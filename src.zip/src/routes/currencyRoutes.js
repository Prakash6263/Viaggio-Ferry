const express = require("express")
const router = express.Router()
const { getCurrencies, getCurrencyByCode } = require("../controllers/currencyController")

router.get("/", getCurrencies)
router.get("/:code", getCurrencyByCode)

module.exports = router
